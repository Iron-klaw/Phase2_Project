import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountsServiceService } from 'src/app/account/accounts-service.service';
import { ItemsServiceService } from 'src/app/items/items-service.service';
import { Items } from 'src/app/items/items';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  newPassword='';
  constructor(private _as:AccountsServiceService,private route: ActivatedRoute,private _itemService:ItemsServiceService, private _router: Router) { 
    this.getAllItems();
  }
  sub:any;
  uname:string='';
  items?:Items[];
  y?:Items[];
  name='';
  cnt:number=0;
  newName:string='';
  newPrice:number=0;
  newCalories:number=0;
  newDescription:string='';
  newQtyAvailable:number=0;
  x:any;
  getAllItems(){
    this.items=this._itemService.getAllItems();
  }
  getItemByName(){
    this.y=this._itemService.getItemByName(this.name);
  
  }
  addItem(){
    this.x={"id":this.cnt,"itemName":this.newName,"price":this.newPrice,"calories":this.newCalories,"description":this.newDescription,"qtyAvailable":this.newQtyAvailable};
    this._itemService.addItem(this.x);
  }
  orderItem(id:any){
    this._router.navigate(['./order',id]);
  }

    ngOnInit() {
    
      this.sub = this.route.params.subscribe(params => {
        console.log(params);
        this.uname=params["uname"];
      });
    }

    changePassword(){
      this.sub = this.route.params.subscribe(params => {
        console.log(params);
        this._as.adminChangePassword(this.newPassword,params["uname"]);
      });
  
   
  }

}
