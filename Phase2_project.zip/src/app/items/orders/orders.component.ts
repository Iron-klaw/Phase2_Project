import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemsServiceService } from '../items-service.service';
import { Items } from '../items';


@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

qty=0;
item:Items={};
sub:any;
id:number=0;;
  constructor(private _is:ItemsServiceService,private route: ActivatedRoute, private _router:Router) { 
    
  }
getById(id:number){
  this.item=this._is.getItemById(id)[0];
}

ngOnInit(): void {
  this.sub = this.route.params.subscribe(params => {
    console.log(params);
    this.id=params["id"];
  });
  this.getById(this.id);
}
placeOrder(){
  this._is.orderItem(this.id,this.qty);
this._router.navigate(['items']);
}

}
