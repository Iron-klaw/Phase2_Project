import { Injectable } from '@angular/core';
import { Items } from './items';

@Injectable({
  providedIn: 'root'
})
export class ItemsServiceService {

  item?:Items;
items:Items[]=new Array<Items>(
  new Items(1001,"Dose",50,100,"Masala Dosa with ChatniPudi",10),
  new Items(1002,"Idli",30,50,"Idly with Chatni and Sambar",100),
  new Items(1003,"Vade",15,150,"Fried Vade",8),
  new Items(1004,"Chow Chow Bath",40,80,"Kharabath and Kesaribath",8),
  new Items(1005,"Puliogere",70,90,"Traditional Karnataka Rice",15),
  new Items(1006,"Bisi Bele Bath",60,125,"Ready made Rice with Sambar",16),

);
  constructor() {

   }
   getAllItems(){
     return this.items;
   }
   getItemByName(name:string){
    return this.items.filter(x=>x.itemName===name);
   }

   orderItem(itemId:number,qty:number){
    var ind = this.items.indexOf(this.items.filter(x=>x.id==itemId)[0]);
    this.item=this.items.filter(x=>x.id==itemId)[0];
    this.item.qtyAvailable=Number(this.item.qtyAvailable)-qty;
    this.items.splice(Number(ind),1,this.item);
   }
   
   addItem(i:any){
      this.items.push(i);
   }
   getItemById(id:number){
return this.items.filter(x=>x.id==id);
   }
}
