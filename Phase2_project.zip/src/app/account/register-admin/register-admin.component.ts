import { Component, OnInit } from '@angular/core';
import { AccountsServiceService } from '../accounts-service.service';

@Component({
  selector: 'app-register-admin',
  templateUrl: './register-admin.component.html',
  styleUrls: ['./register-admin.component.css']
})
export class RegisterAdminComponent implements OnInit {

  cust:any;
  newUname='';
  newPwd='';
  constructor(private _ac:AccountsServiceService) { }
  addAdmin(){
    this.cust= {"id":0,"uname":this.newUname,"pwd":this.newPwd,"role":"admin"}
     this._ac.addCust(this.cust);
   }

  ngOnInit(): void {
  }

}
