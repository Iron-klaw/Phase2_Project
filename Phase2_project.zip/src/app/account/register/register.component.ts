import { Component, OnInit } from '@angular/core';
import { AccountsServiceService } from '../accounts-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

newUname='';
newPwd='';
cust:any;
msg?:string;
  constructor(private _ac:AccountsServiceService) { }
addCust(){
  this.cust= {"id":0,"uname":this.newUname,"pwd":this.newPwd,"role":"cust"}
  this._ac.addCust(this.cust);
  this.msg="Customer Registered Succesfully";
}

  ngOnInit(): void {
  }

}
