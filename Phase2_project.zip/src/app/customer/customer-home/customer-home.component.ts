import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountsServiceService } from 'src/app/account/accounts-service.service';
import { ItemsServiceService } from 'src/app/items/items-service.service';
import { Items } from 'src/app/items/items';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {

  constructor(private _as:AccountsServiceService,private route: ActivatedRoute,private _itemService:ItemsServiceService, private _router: Router) { 
    this.getAllItems();
  }
  sub:any;
  uname:string='';
  items?:Items[];
  y?:Items[];
  name='';
  cnt:number=0;
  newName:string='';
  newPrice:number=0;
  newCalories:number=0;
  newDescription:string='';
  newQtyAvailable:number=0;
  x:any;
  getAllItems(){
    this.items=this._itemService.getAllItems();
  }
  getItemByName(){
    this.y=this._itemService.getItemByName(this.name);
  
  }

  orderItem(id:any){
    this._router.navigate(['./order',id]);
  }

    ngOnInit() {
    
      this.sub = this.route.params.subscribe(params => {
        console.log(params);
        this.uname=params["uname"];
      });
    }

}
