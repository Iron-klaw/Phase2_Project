import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { FormsModule } from '@angular/forms';
import { AccountModule } from '../account/account.module';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    CustomerHomeComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    AccountModule,
    RouterModule,
  ]
})
export class CustomerModule { }